# Evidence mapping to the 30-day AI PM route

Reuse evidence across the five artifacts. The harness is a prepared component of the course, not implementation of every architecture described in the reference handbook. It does not contain real embeddings, a reranker, LLM inference, prompt optimization, interviews or an autonomous agent. Those require separately authorized extensions or clear design artifacts.

| Days | Laboratory evidence | Portfolio destination |
| --- | --- | --- |
| 1, 2, 6, 7 | Lab G opportunity choice; real or authorized-source discovery recorded separately; Lab A baseline | 1 Opportunity and buyer brief |
| 3, 4, 5 | Labs A and D: contract/context trace, eligible configuration comparison, model-cost limits | 2 Product/system decision pack; 3 Evaluation/risk dossier |
| 8, 9, 10 | Labs A and B: corpus eligibility, parsing/chunk comparison, candidate versus assembled evidence | 2 and 3 |
| 11 | Recovery/preview UX design from denied and unavailable outcomes; actual observation recorded separately | 1 and 2 |
| 12, 13, 14 | Lab C tool contract, repeated attempts, termination, authority; unseen checkpoint task | 2, 3 and 5 Executive operating memo |
| 15, 16, 17 | Labs A, B and E: task labels, synthetic judge-candidate calibration, regression and causal measurement limits | 3; 4 Commercial/measurement model |
| 18, 19, 20, 21 | Labs B and C scope tests, trajectories and dashboard; paper memory lifecycle template, correction and unseen review | 3 and 5 |
| 22, 23, 24 | Labs D and G: cost sensitivity, feasible investment, vendor and exit recommendation | 4 and 5 |
| 25, 26, 27 | Labs E and F: corrected experiment readout, unfamiliar finance task, reviewer repair | 3, 4 and 5 |
| 28, 29, 30 | Defended capstone and challenged senior decisions using fresh tasks and rubric anchors | All five artifacts |

For each evidence item record: day, artifact version, case ids, hypothesis, configuration hash, raw snapshot hash, command, metric numerator/denominator, severity, synthetic/real status, decision, owner, rejected alternative and reversal condition. A new diagram without observed or reproducible evidence does not establish an improved outcome.

