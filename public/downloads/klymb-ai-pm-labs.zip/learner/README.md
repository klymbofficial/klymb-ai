# AI Product Management decision laboratory

This package lets you investigate an unreliable support copilot, change its configuration, measure the result and defend an investment decision. It uses Python's standard library. Python 3.10 or later is sufficient; there are no dependencies to install, credentials to enter or API charges.

All organizations, interviews, tasks, rates and demand signals are fabricated teaching fixtures. Retrieval is lexical overlap. Answers are selected from deterministic response replays when evidence conditions match. Token counts and latency are recorded assumptions, not measurements from an actual model. `swift` and `steady` are fictional configurations, not vendor products. The engine is intentionally inspectable. Passing this simulation does not establish that an LLM or production system is reliable.

## Start

Extract the learner ZIP, open a terminal in the `learner` directory and run:

```text
python3 run_lab.py evaluate
python3 run_lab.py trace --case D01 --output outputs/trace_D01.json
python3 run_lab.py dashboard
```

On Windows, use `py -3` instead of `python3` if that is your installed launcher. Open `outputs/dashboard.html` in your browser. It is an offline file with no scripts or network requests. If Python is unavailable, inspect the supplied JSON and use a spreadsheet, declaring that you did not independently execute the harness.

## Commands and outputs

| Command | Purpose | Default output |
| --- | --- | --- |
| `evaluate` | Score all ten development cases in their supplied order | `outputs/evaluate.json` |
| `trace --case D01` | Inspect one case including retrieval, context, cache origin, tools and costs | `outputs/trace.json` |
| `configure --set FIELD=VALUE --output configs/v2.json` | Create a new version from baseline; repeat `--set` for multiple changes | Your chosen config path |
| `compare --left configs/baseline.json --right configs/v2.json` | Compare configurations on identical development cases | `outputs/compare.json` |
| `cost --config configs/v2.json` | Show outcome costs and their components | `outputs/cost.json` |
| `experiment --config configs/v2.json` | Inspect completion evidence for two synthetic arms | `outputs/experiment.json` |
| `transfer --config configs/v2.json` | Run a financial-reporting case with a different user and consequence of error | `outputs/transfer.json` |
| `dashboard --report outputs/evaluate.json` | Render a local control tower from an evaluation report | `outputs/dashboard.html` |

All commands except `configure` accept `--output` to choose a versioned report path. The dashboard also accepts `--output`. Trace runs the complete ordered case batch before selecting your case, preserving interactions between requests. It is not an isolated-case execution. Keep case order unchanged for fair comparisons, then separately test what changing order does. Reusing an output path replaces that report, so choose distinct filenames when preserving evidence. `configure` refuses to overwrite an existing config.

Example of the configuration interface, without a recommended setting:

```text
python3 run_lab.py configure --base configs/baseline.json --set model=steady --output configs/model_trial.json
python3 run_lab.py compare --left configs/baseline.json --right configs/model_trial.json --output outputs/model_trial_compare.json
```

Allowed configuration values are visible in `run_lab.py` and `configs/baseline.json`. Select a value because a trace supports a hypothesis. Changing every field at once cannot show which change caused an improvement. Raw teaching data is protected by `data/manifest.json`; do not edit it to make an answer pass. Configurations and engine improvements belong under version control or in preserved copies. Reset from the original package if integrity verification fails.

## Evidence interpretation

Development labels describe intended outcomes. They are available for debugging; instructor-held cases are not part of the learner package. Avoid claiming held-out performance by repeatedly inspecting the development labels. `answer_accuracy` is exact agreement with fixture labels. `retrieval_recall` includes only cases whose label requires a document, and a hit is the required document appearing among retrieved candidates. `grounded_safe_completion_rate` requires the labeled outcome, its labeled citation when applicable, and passing the simulated context/cache scope checks. Correct abstention, blocked action and bounded termination are legitimate outcomes in their labeled cases.

`safe` checks unauthorized assembled context and incompatible cache origins. It is not a comprehensive security score. Tool authorization must be checked separately from trajectories. Tool actions use a local mock and never affect real accounts. Response caching still incurs retrieval and embedding assumptions, and a reviewed cached response still incurs review labor. Tools are not response-cached. Per-request cost includes model replay, retrieval, embedding, charged tool attempts and indicated review labor. A budget-exhaustion marker is not a charged tool attempt. There is no assumed extra model call per tool attempt.

Cost per verified safe outcome uses all charged requests in the numerator and only labeled, grounded, scope-safe outcomes in the denominator. Report the counts as well as the ratio. The fixture models share answer patterns; changing model names explores cost sensitivity, not evidence of real model capability. An improved replay cannot establish business impact, user adoption or production tail latency.

The experiment command provides an approximate normal confidence interval for instruction. It does not establish significance or justify shipping. Examine event identity, randomized unit, exposure, assignment integrity, independence, missingness, latency and adverse outcomes. The small supplied sample is insufficient for a reliable launch conclusion. Its confidence interval is deliberately not clipped to probability bounds because it is an interval for a difference, not one probability.

## Your submission

Read `learner_briefs.md`. Maintain one hypothesis ledger, immutable baseline evidence, versioned configurations and a decision memo. Record two plausible explanations before inspecting each failure. Supply the command, input/config hash, numerator, denominator and severity for every result. A reviewer must be able to reproduce your claim. Do not publish synthetic outcomes as customer results or fabricated interviews as real discovery.

The commercial exercise is a judgment task using `data/commercial.json`; it has no automatically correct investment choice. Primary discovery or an authorized workplace case must be separately documented. A reviewer evaluates the evidence and reasoning, not whether your choice matches a preferred product. Consult `rubrics.md` and `evidence_map.md` for the assessment and daily evidence mapping.


## Additional manual state and grader exercises

Use templates/memory_records.json for a paper lifecycle/state table, and templates/judge_candidates.json for a blind rubric exercise. Neither is a running memory system or a real LLM judge. Keep original inputs, freeze your proposed states/scores, then request instructor review and reference anchors. Actual memory deletion and live model-judge calibration require a separately implemented and authorized system.
