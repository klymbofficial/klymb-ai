#!/usr/bin/env python3
"""Offline, synthetic AI product lab. Standard library only. No inference or network."""
import argparse, hashlib, html, json, math, re, statistics, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUT = ROOT / 'outputs'
ENUMS = {'parser':('flat','preserve_table'),'chunk_mode':('fixed','section'),
 'context_mode':('first_excerpt','selected'),'version_mode':('all','current'),
 'access_mode':('display','prefilter'),'identifier_mode':('normalized','exact'),
 'cache_scope':('query','scoped','off'),'event_mode':('all','unique'),'model':('swift','steady')}
DISCLAIMER = 'Fabricated data. Deterministic response replay, lexical retrieval, simulated token counts and recorded latency assumptions. Not live inference or a model benchmark.'

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, value):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def verify_data():
    m = load(DATA/'manifest.json')
    for name, digest in m['sha256'].items():
        if hashlib.sha256((DATA/name).read_bytes()).hexdigest() != digest:
            raise ValueError('Raw-data integrity mismatch: '+name+'. Restore the original teaching snapshot.')
    return hashlib.sha256((DATA/'manifest.json').read_bytes()).hexdigest()

def config(path):
    c = load(path)
    if c.get('schema_version') != 1: raise ValueError('Unsupported configuration schema.')
    for k, choices in ENUMS.items():
        if c.get(k) not in choices: raise ValueError(f'{k} must be one of {choices}')
    for k, lo, hi in [('retrieval_k',1,20),('context_chars',50,10000),('max_tool_calls',1,20)]:
        if not isinstance(c.get(k),int) or not lo <= c[k] <= hi: raise ValueError(f'{k} must be an integer from {lo} to {hi}')
    return c

def tokens(s):
    return set(re.findall(r'[a-z0-9]+',s.lower())) - {'the','for','a','an','and','to','of','is'}

def parse_document(d,c):
    sections = [d['title']+'\n'+s for s in d['sections']]
    if c['parser']=='preserve_table': sections.append('\n'.join(f"{r['field']}={r['value']}" for r in d['table']))
    body = '\n'.join(sections)
    chunks = sections if c['chunk_mode']=='section' else [body[n:n+160] for n in range(0,len(body),160)]
    return body, chunks

def current(d,date):
    return d['valid_from'] <= date and (d['valid_to'] is None or date < d['valid_to'])

def permitted(d,t):
    return d['tenant']==t['tenant'] and t['role'] in d['acl']

def retrieve(t,c,corpus):
    q = tokens(t['query']); hits=[]
    for d in corpus:
        if c['access_mode']=='prefilter' and not permitted(d,t): continue
        if c['version_mode']=='current' and not current(d,t['as_of']): continue
        body,chunks=parse_document(d,c)
        score=len(q & tokens(body))/max(1,len(q))
        if score:
            hits.append(dict(id=d['id'],tenant=d['tenant'],acl=d['acl'],version=d['version'],current=current(d,t['as_of']),permitted=permitted(d,t),score=round(score,4),body=body,chunks=chunks))
    # Stable ordering matters when several candidates score equally.
    hits.sort(key=lambda d:d['score'],reverse=True)
    return hits[:c['retrieval_k']]

def assemble(hits,c):
    if not hits: return '',[]
    selected = hits[:1] if c['context_mode']=='first_excerpt' else hits
    pieces=[]; source_ids=[]; left=c['context_chars']
    for d in selected:
        chunks=d['chunks'][:1] if c['context_mode']=='first_excerpt' else d['chunks']
        added=False
        for chunk in chunks:
            part=chunk[:left]
            if part: pieces.append(part);left-=len(part);added=True
            if left<=0: break
        if added: source_ids.append(d['id'])
        if left<=0: break
    return '\n'.join(pieces),source_ids

def unique_events(events,c):
    if c['event_mode']=='all': return events
    seen=set(); result=[]
    for e in events:
        if e['event_id'] not in seen: result.append(e);seen.add(e['event_id'])
    return result

def run_tool(t,c,assets):
    spec=t.get('tool'); trajectory=[]
    if not spec: return {},trajectory
    requested=spec.get('requested_calls',1)
    for attempt in range(requested):
        if attempt>=c['max_tool_calls']:
            result={'status':'budget_exhausted'}
            trajectory.append({'step':attempt+1,'name':spec['name'],'status':'budget_exhausted','charged':False})
            return result,trajectory
        name=spec['name'];args=spec['args']; result={'status':'denied','reason':'unknown_tool'}
        if name=='lookup_ticket':
            query=args.get('ticket_id','')
            match=lambda value: value==query if c['identifier_mode']=='exact' else re.sub(r'\W','',value).lower()==re.sub(r'\W','',query).lower()
            candidates=[row for row in assets['tickets'] if match(row['id'])]
            if not candidates: result={'status':'not_found'}
            elif candidates[0]['tenant']!=t['tenant']: result={'status':'denied','reason':'tenant_scope'}
            else: result={'status':candidates[0]['status'],'ticket_id':candidates[0]['id']}
        elif name=='cancel_account':
            # The environment is a local mock. It cannot change any real account.
            if t['role']=='finance' and args.get('approval') is True:
                result={'status':'simulated_cancelled','account_id':args.get('account_id'),'effect':'mock_only'}
            else: result={'status':'denied','reason':'approval_and_finance_role_required'}
        elif name=='summarize_revenue':
            if t['role']!='finance': result={'status':'denied','reason':'finance_role_required'}
            else:
                rows=[r for r in assets['orders'] if r['tenant']==t['tenant'] and r['month']==args.get('month') and r['status']=='valid']
                if c['event_mode']=='unique': rows=list({r['order_id']:r for r in rows}.values())
                result={'status':'ok','revenue':sum(r['amount'] for r in rows),'rows':len(rows),'currency':'USD'}
        trajectory.append({'step':attempt+1,'name':name,'args':args,'result':result,'charged':True})
        if result['status']=='denied': break
    return result,trajectory

def replay(t,c,ctx,tool,hits,context_ids,replays):
    tooltext=' '.join(f'{k}={v}' for k,v in tool.items())
    for r in replays:
        if r['task_key']!=t['replay_key'] or r['model']!=c['model']: continue
        if all(term in ctx for term in r['requires_context']) and all(term in tooltext for term in r['requires_tool']):
            candidates=[h['id'] for h in hits if h['id'] in context_ids and any(term in h['body'] for term in r['requires_context'])]
            citations=candidates or (context_ids if r['value'] is not None else [])
            return dict(r, citations=citations, abstained=r['value'] is None)
    raise ValueError('No response fixture matched the requested replay key.')

def money(r,trajectory,assets,cache_hit=False):
    p=assets['pricing'];rates=p['models'][r['model']]
    model=0 if cache_hit else (r['input_tokens']*rates['input_per_million']+r['output_tokens']*rates['output_per_million'])/1000000
    tools=sum(x['charged'] for x in trajectory)*p['tool_per_call']
    review=p['human_hourly_usd']*p['review_seconds']/3600 if r['needs_review'] else 0
    return {'model_usd':model,'retrieval_usd':p['retrieval_per_request'],'embedding_usd':p['embedding_per_request'],'tools_usd':tools,'human_review_usd':review,'total_usd':round(model+p['retrieval_per_request']+p['embedding_per_request']+tools+review,8)}

def execute(c,cases,labels=None):
    if not cases: raise ValueError('At least one case is required.')
    if len({t['id'] for t in cases})!=len(cases): raise ValueError('Case ids must be unique.')
    if labels is not None and any(t['id'] not in labels for t in cases): raise ValueError('Every case must have a label.')
    digest=verify_data()
    assets={k:load(DATA/file) for k,file in [('corpus','policies.json'),('tickets','tickets.json'),('orders','orders.json'),('replays','response_replays.json'),('pricing','pricing_assumptions.json')]}
    cache={};results=[]
    for t in cases:
        hits=retrieve(t,c,assets['corpus']);ctx,ids=assemble(hits,c)
        tool,trajectory=run_tool(t,c,assets)
        key=t['query'] if c['cache_scope']=='query' else json.dumps([t['query'],t['tenant'],t['role'],t['as_of'],digest,c['model'],t.get('tool')],sort_keys=True)
        # Tool actions are never cached; response replays with a tool are recomputed.
        cache_hit=c['cache_scope']!='off' and key in cache and not t.get('tool')
        if cache_hit: r,origin=cache[key]
        else:
            r=replay(t,c,ctx,tool,hits,ids,assets['replays']);origin=t
            if c['cache_scope']!='off' and not t.get('tool'): cache[key]=(r,t)
        exposed=[h['id'] for h in hits if h['id'] in ids and not h['permitted']]
        cache_scope_error=cache_hit and (origin['tenant']!=t['tenant'] or origin['role']!=t['role'] or origin['as_of']!=t['as_of'])
        safe=not exposed and not cache_scope_error
        result={'case_id':t['id'],'query':t['query'],'tenant':t['tenant'],'role':t['role'],'as_of':t['as_of'],'answer':r['answer'],'value':r['value'],'citations':r['citations'],'abstained':r['abstained'],'needs_review':r['needs_review'],'safe':safe,'unauthorized_context_ids':exposed,'cache_hit':cache_hit,'cache_origin_case':origin['id'],'cache_scope_error':cache_scope_error,'retrieval':[dict(h,body=None,chunks=None) for h in hits],'context':ctx,'context_ids':ids,'tool':tool,'trajectory':trajectory,'input_tokens_recorded':0 if cache_hit else r['input_tokens'],'output_tokens_recorded':0 if cache_hit else r['output_tokens'],'latency_ms_assumed':70+(0 if cache_hit else r['model_latency_ms'])+40*sum(x['charged'] for x in trajectory),'cost':money(r,trajectory,assets,cache_hit)}
        if labels is not None:
            y=labels[t['id']]
            correct=result['value']==y['value'] and (not y.get('abstain') or result['abstained'])
            if y.get('blocked'): correct=correct and tool.get('status')=='denied'
            if y.get('bounded'): correct=correct and tool.get('status')=='budget_exhausted'
            result.update(answer_correct=correct,grounded_correct=correct and (y['doc'] is None or y['doc'] in result['citations']),retrieved_target=y['doc'] is None or y['doc'] in [h['id'] for h in hits],gold_requires_document=y['doc'] is not None)
        results.append(result)
    n=len(results)
    summary={'requests':n,'raw_snapshot_hash':digest,'config_hash':hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),'model':c['model'],'cost_total_usd':round(sum(r['cost']['total_usd'] for r in results),8),'human_review_total_usd':round(sum(r['cost']['human_review_usd'] for r in results),8),'safety_passes':sum(r['safe'] for r in results),'abstentions':sum(r['abstained'] for r in results),'tool_calls_charged':sum(x['charged'] for r in results for x in r['trajectory']),'latency_p50_ms_assumed':statistics.median(r['latency_ms_assumed'] for r in results),'latency_p95_ms_assumed':sorted(r['latency_ms_assumed'] for r in results)[max(0,math.ceil(n*.95)-1)]}
    if labels is not None:
        correct=sum(r['answer_correct'] for r in results);safe_correct=sum(r['grounded_correct'] and r['safe'] for r in results)
        req=[r for r in results if r['gold_requires_document']]
        summary.update(answer_correct_count=correct,answer_accuracy=correct/n,grounded_safe_completion_count=safe_correct,grounded_safe_completion_rate=safe_correct/n,retrieval_recall_numerator=sum(r['retrieved_target'] for r in req),retrieval_recall_denominator=len(req),retrieval_recall=sum(r['retrieved_target'] for r in req)/len(req) if req else None,cost_per_verified_safe_outcome_usd=round(summary['cost_total_usd']/safe_correct,8) if safe_correct else None)
    return {'disclaimer':DISCLAIMER,'config':c,'summary':summary,'results':results}

def experiment(c):
    verify_data();raw=load(DATA/'events.json');events=unique_events(raw,c);arms={}
    for arm in ('control','treatment'):
        rows=[e for e in events if e['arm']==arm];n=len(rows);success=sum(e['completed'] for e in rows);p=success/n
        arms[arm]={'event_denominator':n,'unique_units':len({e['unit_id'] for e in rows}),'completed':success,'completion_rate':p,'latency_mean_ms_assumed':statistics.mean(e['latency_ms'] for e in rows)}
    a,b=arms['control'],arms['treatment'];delta=b['completion_rate']-a['completion_rate']
    se=math.sqrt(sum(v['completion_rate']*(1-v['completion_rate'])/v['event_denominator'] for v in arms.values()))
    return {'disclaimer':DISCLAIMER,'arms':arms,'duplicate_events_in_raw':len(raw)-len({e['event_id'] for e in raw}),'difference_treatment_minus_control':delta,'approximate_95_percent_CI':[delta-1.96*se,delta+1.96*se],'interpretation':'Small synthetic sample. Normal approximation for teaching only. Repeated events are not independent randomized units. No shipping conclusion is supported by this interval alone.'}

def dashboard(report,path):
    rows=[]
    for r in report['results']:
        cells=[r['case_id'],r['answer'],str(r.get('answer_correct','not scored')),str(r['safe']),str(r['cache_hit']),str(r['latency_ms_assumed']),f"${r['cost']['total_usd']:.5f}"]
        rows.append('<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in cells)+'</tr>')
    content='<!doctype html><html lang="en"><meta charset="utf-8"><title>AI Product Control Tower</title><style>body{font:16px system-ui;margin:32px;max-width:1400px;color:#17233c}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd3df;padding:10px;text-align:left}th{background:#e8edf5}pre{white-space:pre-wrap;background:#f4f6fa;padding:16px}caption{text-align:left;font-size:22px;padding:16px 0}</style><h1>AI Product Control Tower</h1><p>'+html.escape(DISCLAIMER)+'</p><pre>'+html.escape(json.dumps(report['summary'],indent=2))+'</pre><table><caption>Case outcomes</caption><thead><tr>'+''.join('<th>'+x+'</th>' for x in ['Case','Answer','Correct','Safe','Cache hit','Assumed ms','Cost'])+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table><p>This local file contains no scripts, network requests or user data.</p></html>'
    Path(path).parent.mkdir(parents=True,exist_ok=True);Path(path).write_text(content,encoding='utf-8')

def main(argv=None):
    p=argparse.ArgumentParser(description=DISCLAIMER);sp=p.add_subparsers(dest='command',required=True)
    for name in ['evaluate','trace','cost','experiment','transfer']:
        q=sp.add_parser(name);q.add_argument('--config',default=str(ROOT/'configs'/'baseline.json'));q.add_argument('--output')
        if name=='trace': q.add_argument('--case',required=True)
        if name=='evaluate': q.add_argument('--cases');q.add_argument('--labels')
    q=sp.add_parser('configure');q.add_argument('--base',default=str(ROOT/'configs'/'baseline.json'));q.add_argument('--set',action='append',default=[]);q.add_argument('--output',required=True)
    q=sp.add_parser('compare');q.add_argument('--left',required=True);q.add_argument('--right',required=True);q.add_argument('--output')
    q=sp.add_parser('dashboard');q.add_argument('--report',default=str(OUT/'evaluate.json'));q.add_argument('--output',default=str(OUT/'dashboard.html'))
    a=p.parse_args(argv)
    if a.command=='configure':
        c=config(a.base)
        for setting in a.set:
            k,v=setting.split('=',1)
            if k not in c or k=='schema_version': raise ValueError('Unknown or immutable configuration field: '+k)
            c[k]=int(v) if isinstance(c[k],int) else v
        if Path(a.output).exists(): raise ValueError('Config already exists. Choose a new version filename.')
        save(a.output,c)
        try: config(a.output)
        except Exception:
            Path(a.output).unlink();raise
        print('Created versioned configuration: '+a.output);return
    if a.command=='dashboard': dashboard(load(a.report),a.output);print('Dashboard: '+a.output);return
    if a.command=='compare':
        cases=load(DATA/'cases.json');labels=load(DATA/'labels_dev.json')
        left=execute(config(a.left),cases,labels);right=execute(config(a.right),cases,labels)
        report={'disclaimer':DISCLAIMER,'left':left['summary'],'right':right['summary'],'changed_cases':[{'case_id':l['case_id'],'before':l['value'],'after':r['value'],'before_safe':l['safe'],'after_safe':r['safe']} for l,r in zip(left['results'],right['results']) if (l['value'],l['safe'])!=(r['value'],r['safe'])]}
    elif a.command=='experiment': report=experiment(config(a.config))
    else:
        transfer=a.command=='transfer'
        cases=load(a.cases) if getattr(a,'cases',None) else load(DATA/('transfer.json' if transfer else 'cases.json'))
        labels=load(a.labels) if getattr(a,'labels',None) else load(DATA/('labels_transfer.json' if transfer else 'labels_dev.json'))
        report=execute(config(a.config),cases,labels)
        if a.command=='trace':
            matching=[r for r in report['results'] if r['case_id']==a.case]
            if not matching: raise ValueError('Unknown case id: '+a.case)
            report={'disclaimer':DISCLAIMER,'config':report['config'],'result':matching[0]}
        elif a.command=='cost': report={'disclaimer':DISCLAIMER,'summary':report['summary'],'case_costs':[{'case_id':r['case_id'],**r['cost']} for r in report['results']]}
    dest=a.output or str(OUT/(a.command+'.json'))
    save(dest,report)
    print(json.dumps(report.get('summary',report),indent=2));print('Saved: '+dest)

if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,OSError,json.JSONDecodeError) as e:
        print('ERROR: '+str(e),file=sys.stderr);sys.exit(2)
