# Laboratory assessment anchors

These laboratory rubrics explain evidence quality. They do not replace the handbook's diagnostic, checkpoint or capstone weights. The instructor maps this evidence into the relevant course rubric. Senior competence requires defensible decisions under uncertainty, not merely selecting a reference configuration.

## Technical evidence: 100 points

| Criterion | Points | Full-credit evidence |
| --- | --- | --- |
| Diagnosis and causal isolation | 20 | Two credible hypotheses; traces locate first divergence; one-factor or justified factorial comparison |
| Evaluation and generalization | 20 | Frozen development set, severity slices, numerator/denominator, separate held-out review and an unfamiliar transfer test |
| Authority and reliability | 20 | Context and tool boundaries, negative tests, bounded termination, deterministic denial and meaningful regression evidence |
| Economics and measurement | 15 | Cost components reconcile; outcome denominator is explicit; synthetic assumptions and missing costs remain labeled |
| Product decision | 15 | Feasible choice, rejected alternative, launch restriction, owner and evidence that would reverse the choice |
| Reproducibility and communication | 10 | Versioned command/config/data hashes, readable trace evidence and a concise explanation an engineer can challenge |

75 points and at least half the points in every criterion is the laboratory evidence threshold. A critical authorization failure, data tampering, fabricated real-world evidence or recommendation for an uncontrolled destructive action blocks a pass regardless of total. Repair and reassess on a fresh case. This is a course policy for the simulation, not an empirical guarantee of production safety.

Transition evidence uses guided comparisons and explains the request path correctly. Advanced evidence also survives changed order, a new buyer/task mix, a conflicting resource constraint and a challenged recommendation. Vocabulary, number of tools and complexity receive no points by themselves.

## Commercial decision: 100 points

| Criterion | Points | Full-credit evidence |
| --- | --- | --- |
| Job, baseline and buyer | 20 | Concrete job, current alternative, economic buyer and reason AI adds incremental value or should be omitted |
| Evidence strength | 20 | Attributed observations, disconfirming evidence, synthetic versus real separation and unresolved demand/payment assumptions |
| Portfolio and procurement constraints | 20 | Feasible cash and role capacity allocation, eligible vendor options, use rights, deletion/exit requirements and opportunity cost |
| Unit economics and uncertainty | 15 | Outcome and human effort costs, adoption and monetization assumptions, sensitivity and honest missing inputs |
| Experiment and rollout | 15 | A falsifiable value test, assignment/exposure definition, review capacity, staged scope and stop/rollback authority |
| Defense and ownership | 10 | A concise decision, rejected alternative, reversal condition and named functions accountable for delivery and risk |

The same 75-point, half-per-criterion and critical-failure gates apply. There is no uniquely correct bet, price or launch decision. A carefully defended stop decision can earn full credit. Comparing synthetic interview quotes is practice, not a primary-discovery credential.

## Reviewer protocol

Two reviewers independently score one exemplar before cohort delivery. Resolve criterion differences greater than five points, record anchors and repeat on a weak submission. Return one strength, the consequential evidence gap, a concrete repair and a fresh reassessment condition. Do not promise review turnaround, named expertise or access until the provider can demonstrate those capabilities. Reviewer feedback and calibration remain human delivery work; executable tests cover only the simulated mechanism.

