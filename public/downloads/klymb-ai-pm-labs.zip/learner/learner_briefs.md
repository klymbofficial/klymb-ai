# Learner briefs

These briefs expose symptoms and decisions. They do not identify the intended fault or prescribe a fix. Use the same evidence discipline on each: THINK of two plausible explanations, BUILD a controlled comparison, BREAK with an adversarial or changed case, DEBUG the first divergence, DECIDE a bounded change, and DEFEND it with a reversal condition.

## Lab A: Useful evidence, unreliable answers

The sponsor says the relevant policies often appear in search results, yet frontline staff cannot consistently use the resulting drafts. Inspect D01, D03 and D04 along with successful or abstaining cases. You have one engineering day for the first intervention.

Produce a request-path diagram, a trace-backed hypothesis ledger, one changed configuration, a comparison and a rejected alternative. Identify what the current retrieval metric can and cannot establish. Demonstrate that a local improvement does not create an unsupported promise in another case. Do not explain a failure by saying only that the model hallucinated.

## Lab B: Repeated requests and confidentiality

Support managers report that similar questions behave differently when submitted in different work contexts. An executive asks whether a single favorable demonstration proves readiness for more customers. Inspect D01, D02, D05, D07 and D10 in their ordered sequence and then consider a changed order.

Produce an authorization boundary, a freshness requirement, a response-reuse policy and negative tests. Choose whether to launch, restrict or stop. Your memo must separate correct text from permitted evidence and define who owns denial behavior. A correct number from an unauthorized source is a failed product outcome. Do not infer comprehensive security from the harness's limited `safe` flag.

## Lab C: Tool reliability and automation scope

Finance disputes a ticket status. Operations sees repeated tool activity for a request that should have reached a useful terminal state. The sponsor wants account changes enabled next week. Inspect D06, D08 and D09.

Produce a tool contract, state/termination sketch, a controlled fix and an automation recommendation. Account for charged attempts and human review. Distinguish a proposed action, an approved action and an executed action. Specify what the server must enforce even if the generated instruction appears valid. Explain which additional tests the local mock cannot provide.

## Lab D: Quality, review labor and cost

Leadership considers using a more expensive configuration for every interaction because it sounds more capable. You must show cost per useful outcome and a sensitivity range without claiming unmeasured model superiority.

Compare at least two model/configuration choices on identical cases. Use `cost` and inspect component totals. Recalculate one case by hand and reconcile the full batch. Then project 100,000 monthly users with 12 requests each, stating why a ten-case distribution cannot estimate population performance. Model at least three review-rate assumptions and one changed tool-attempt assumption. Name missing infrastructure costs, buyer value evidence and a budget-based reversal condition.

## Lab E: Experiment and adoption evidence

A dashboard suggests treatment completion improved. Sales wants the result in a launch announcement. Use `experiment`, inspect `data/events.json` and decide whether the claim is supportable.

Produce the assignment unit, measurement unit, exposed denominator, completion numerator and a corrected readout. Calculate an interval, name why its approximation is limited and propose the next experiment. Separate engagement, acceptance, completion, economic value and human effort. You may recommend more evidence or a restricted pilot rather than a winner. Specify monitoring and a stop condition.

## Lab F: Transfer to financial reporting

A finance user needs a February revenue summary while a manager is planning staffing. The outcome affects a different workflow from support. Run `transfer`, inspect supporting records and decide whether an LLM is necessary for the calculation.

Produce a metric contract with entity, time, status, currency and authorized scope; reconcile the calculated value; and choose a deterministic or AI role. Explain what transfers from the support lessons and what requires a new evaluation. A fluent summary cannot replace reconciliation. The fixture is a single task, so propose additional unseen tests instead of claiming broad financial reliability.

## Lab G: Investment committee

You have USD 120,000 cash, 24 engineer-weeks, six designer-weeks and eight ML engineer-weeks this quarter. Three opportunities compete for that capacity. Review the fabricated interviews, willingness-to-pay observations and vendor cards in `data/commercial.json`.

Produce a two-page investment memo, a feasible resource allocation and a one-page economic model. Include the traditional-software alternative. Identify user, sponsor and buyer; evaluate positive and negative evidence; state what is unknown; propose a real purchasing or adoption test. Defend build/buy eligibility, contract/deletion questions and an exit plan. Assign ownership for rollout, review capacity, incidents and stopping.

Do not turn the eight synthetic willingness-to-pay observations into validated demand, multiply annual eligible users by a monthly price without resolving the population definition, or claim payback without volume, adoption, monetization and total-cost assumptions. Multiple decisions can pass when the constraints and evidence support them. Show the condition that would make you fund the rejected option.

## Time and review

Use the daily cohort time budget rather than treating these as seven additional full projects. Each lab contributes to the five connected portfolio artifacts. Every checkpoint uses a fresh task and a live or recorded defense. Submit unresolved risks honestly. A held-out failure may justify narrowing the recommendation rather than manipulating the data or suppressing the case.

